package com.tricon.Student.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.tricon.Student.model.Student;
import com.tricon.Student.service.IStudentService;

@RestController
public class StudentController {

	@Autowired
	private IStudentService  student;
	
	@RequestMapping("/user")
	public List<Student> getAllUsers() {
		System.out.println("Inside: Controller dsdfds sdad  adsad  zssd");
		return student.getAllUsers();
	}
	
	@RequestMapping(value="/user/{id}",method=RequestMethod.GET)
	public Student getUser(@PathVariable int id) {
		System.out.println("Inside: Controller");
		return student.getUser(id);
	}
	
	@RequestMapping(value="/user",method=RequestMethod.POST)
	public String addUser(@RequestBody Student studentObject) {
		System.out.println("Inside: fff Controller");
		return student.addUser(studentObject);
	}
	
	@RequestMapping(value="/user/{id}",method=RequestMethod.DELETE)
	public String User(@PathVariable int id) {
		System.out.println("Inside: fff Controller");
		return student.deleteUser(id);
	}
	
	@RequestMapping(value="/user",method=RequestMethod.PUT)
	public String User(@RequestBody Student studentObject) {
		System.out.println("Inside: uuu Controller");
		return student.updateUser(studentObject);
	}
}
