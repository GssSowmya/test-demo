package com.tricon.Student.service;

import java.util.List;

import com.tricon.Student.model.Student;

public interface IStudentService {
	public List<Student>  getAllUsers();
	public Student getUser(int id);
	public String addUser(Student studentObject);
	public String deleteUser(int id);
	public String updateUser(Student studentObject);
}
